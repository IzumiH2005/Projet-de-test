# examgen — générateur de questions NSI appris sur les annales

Le programme lit les anciens sujets du bac NSI (Terminale) et le cours. Il en apprend la façon dont les épreuves sont construites, puis fabrique des plans de questions. Un agent Opus 5.5 (effort *low*) rédige ces plans. Les modèles appris sur les annales contrôlent ensuite chaque question.

```
annales PDF + cours ──► ingest ──► features (~90 variables/question) ──► analysis (14 modèles)
                                                                              │
             questions.md ◄── validate ◄── agent Opus 5.5 low ◄── plans ◄── blueprint
```

## Corpus

Sources publiques hébergées sur GitHub, récupérées par `scripts/fetch_sources.sh` :

| Source | Contenu |
|---|---|
| [glassus/terminale_nsi](https://github.com/glassus/terminale_nsi) | cours (Markdown), annales écrites, sujets d'épreuve pratique |
| [trahobisoa/Terminale_NSI](https://github.com/trahobisoa/Terminale_NSI) | cours (PDF), annales écrites 2021–2026 |
| [Nota-yob/ECE-NSI-2024](https://github.com/Nota-yob/ECE-NSI-2024) | sujets d'épreuve pratique 2024 |

Après dédoublonnage, le corpus compte :
- 83 sujets écrits uniques (2 668 questions) ;
- 362 exercices pratiques ;
- 281 sections de cours (≈ 790 000 caractères).

## Ce que l'analyse extrait (`examgen/analysis.py`)

1. **Espace sémantique**. Questions et cours sont projetés dans un même espace TF-IDF, réduit par LSA (150 dimensions).
2. **Rattachement au cours**. Chaque notion du programme est reliée à ses sections de cours. Le modèle mesure aussi la part de chaque notion dans le cours et dans les épreuves.
3. **Archétypes de questions**. Un KMeans regroupe les questions selon leur forme et le début de leur consigne. Le nombre de groupes est choisi par silhouette.
4. **Affinité notion × archétype**. Elle indique quelles formes de question vont avec quelle notion. Les notions rares empruntent le profil de leur domaine (lissage bayésien hiérarchique).
5. **Chaîne de Markov**. Elle apprend l'enchaînement des archétypes et des niveaux de Bloom dans un exercice (ouvertures, transitions, fermetures).
6. **Graphe des notions**. Il repose sur la PMI des cooccurrences. On en tire les notions pivots (PageRank), les notions ponts (betweenness) et des blocs thématiques cachés (communautés).
7. **Modèle de difficulté**. Un Gradient Boosting prédit la position d'une question dans l'exercice. L'importance par permutation montre ce qui rend une question « de fin d'exercice ».
8. **Facteurs latents**. Une SVD sur les ~90 variables fait ressortir des facteurs latents.
9. **Règles d'association** (lift), par exemple « lire du SQL ⇒ écrire du SQL ».
10. **Tendances**. Fréquences pondérées par récence, pentes, prévision, et notions enseignées mais peu évaluées.
11. **Changement de format 2022 → 2023**. Comparaison par χ² et divergence de Jensen-Shannon.
12. **Logique d'un sujet**. Comment les domaines se répartissent entre exercices, et comment le Bloom, le code et les dépendances évoluent au fil d'un exercice.
13. **Scénarios d'exercices**. Un NMF dégage les contextes récurrents ; un Isolation Forest repère les questions atypiques.
14. **Classifieur texte → notions**. Une régression logistique *one-vs-rest* sert de validateur. Le Top-3 est correct dans 89 % des cas en validation croisée.

On y ajoute une typologie des exercices pratiques. Le rapport complet se trouve dans `output/rapport_analyse.md`.

## Découverte non supervisée (`examgen/discovery.py`)

Ici, aucune liste de variables n'est écrite à la main. scikit-learn lit 3 102 questions : 2 668 d'écrit, 267 de pratique et 167 exercices du cours. Il en tire lui-même 95 variables, dont 80 sont stables d'un ré-échantillonnage à l'autre.

1. **Séparer la manière de demander du sujet**. Pour chaque mot, on mesure deux choses :
   - s'il est réparti sur tous les thèmes (entropie) ;
   - s'il revient en grappe dans un même exercice.

   Un mélange gaussien en 2D classe alors les mots en « mots de consigne » (967) ou « mots de contenu ». Aucun lexique n'est fourni au départ.
2. **Quatre vues apprises par NMF** :
   - le contenu ;
   - la consigne (le texte où les mots de contenu sont masqués) ;
   - la forme du support (code, nombres, listes, tableaux) ;
   - la mise en situation.

   Le nombre de variables de chaque vue est choisi par stabilité au bootstrap.
3. **Facettes**. Un KMeans, avec un nombre de groupes choisi par silhouette, dégage :
   - 25 manières de demander, par exemple « Prédire le résultat d'un appel », « Compléter des lignes numérotées », « Rôle d'une clé », « Interpréter le résultat d'une requête » ;
   - 8 types de support.

   Un agent Opus 5.5 low les a seulement nommées (`data/model/facet_names.json`).
4. **Grammaire des combinaisons**. Une régression logistique avec interactions apprend quelles combinaisons (notion × manière × support × position) existent vraiment. Elle les distingue de combinaisons corrompues, avec une AUC de 0,69 en validation croisée par sujet. Sur 8 400 combinaisons possibles, 1 313 ont déjà servi. **250 n'ont jamais été posées mais sont jugées aussi plausibles que de vraies questions.** Un filtrage collaboratif (PPMI + SVD) confirme ce transfert.
5. **Savoirs jamais évalués**. Le cours est découpé en 3 179 phrases, dont 477 déjà interrogées aux annales. Un apprentissage positif/non étiqueté (Elkan-Noto) estime quels détails sont évaluables et n'ont pourtant jamais été demandés.
6. **Dynamique des exercices** : 14 types de transition entre questions et 166 motifs de séquence plus fréquents que ne le prévoit Markov.
7. **Moteurs cachés**. Les variables découvertes améliorent la prédiction de la difficulté (R² 0,077 → 0,09 avec les variables manuelles). Elles reconnaissent aussi le format 2023 (AUC 0,77). Le modèle relève enfin les styles en hausse et en baisse, et les questions atypiques.

Résultats : `data/model/discovery.json` et `output/discovery/facettes.md`.

### Questions inédites (`examgen/inedit.py`)

Chaque plan inédit vise une notion et contient deux sortes de questions :
- **combinaison inédite** : une manière de demander ou un support jamais utilisés pour cette notion. Le style est montré par de vraies questions d'autres notions ; on imite la forme, pas le fond.
- **savoir jamais évalué** : un détail du cours que le modèle juge évaluable.

La validation remesure, sur le texte rédigé, la facette et le support (top-3), la plausibilité et la nouveauté de la combinaison.

```bash
python -m examgen.cli discover   # apprend les variables
python -m examgen.cli inedit     # 42 plans, 148 questions -> output/prompts/I-*.md
python -m examgen.cli validate
```

## Génération

- `blueprint.py` tire chaque plan dans les lois apprises.
  - **Mode sujet** : 3 exercices de 6, 6 et 8 points. Les notions sont choisies par PMI, avec une pénalité si un domaine revient. Les questions suivent la chaîne de Markov combinée à l'affinité notion × archétype. Le plan fixe aussi la courbe de difficulté, les dépendances et le barème.
  - **Mode banque** : quelques questions par notion pour couvrir tout le programme, avec des archétypes variés.
- `llm.py` transforme chaque plan en consigne (`output/prompts/<id>.md`). Chaque consigne contient des extraits du cours, des exemples réels de style et une sortie JSON imposée (`_schema.json`).
- La rédaction se fait de deux façons :
  - `--backend agents` : des agents Claude Code Opus 5.5 en effort *low* rédigent `output/generated/<id>.json`. C'est le mode utilisé ici.
  - `--backend api` : appel direct à `claude-opus-5-5` avec `effort: low` et une sortie JSON structurée. Il faut définir `ANTHROPIC_API_KEY`.

## Validation (`validate.py`)

Chaque question générée repasse par la même chaîne que les vraies questions. On vérifie :
- la notion (classifieur, top-3) ;
- l'archétype et le type de tâche ;
- le niveau de Bloom ;
- la nouveauté (similarité maximale avec les 2 668 vraies questions ; au-delà de 0,92, c'est une quasi-copie) ;
- l'ancrage dans le cours ;
- le code Python du corrigé (il doit compiler) et la forme du SQL ;
- la courbe de difficulté (corrélation de Spearman).

## Utilisation

```bash
pip install -r requirements.txt
bash scripts/fetch_sources.sh
python -m examgen.cli all --sujets 2 --par-notion 4   # ingest + analyse + rapport + plans + consignes
python -m examgen.cli write --backend api             # ou faire rédiger par des agents
python -m examgen.cli validate                        # -> output/validation.json + output/questions.md
```

## Résultats de la première génération (205 questions, 2 sujets complets + banque)

| Contrôle | Score |
|---|---|
| Code Python des corrigés qui compile | 100 % |
| SQL bien formé | 100 % |
| Notion reconnue par le lexique du programme | 94 % |
| Notion dans le top-3 du classifieur | 75 % |
| Niveau de Bloom respecté (±1) | 75 % |
| Type de tâche respecté | 68 % |
| Quasi-copies d'annales | 1,5 % (3 questions) |
| Courbe de difficulté (Spearman moyen) | +0,34 |

Le classifieur reconnaît mal les notions rares dans les annales (sgbd, prog_dynamique, algo_simples, web_http). Il en a vu trop peu d'exemples pour bien les apprendre ; ce n'est pas un défaut des questions.

## Résultats des questions inédites (148 questions, 42 notions)

| Contrôle | Score |
|---|---|
| Manière de demander remesurée = celle du plan (top-3) | 71 % (exacte : 57 %) |
| Type de support remesuré = celui du plan (top-3) | 81 % |
| Combinaison (notion, manière, support) absente des annales écrites | 74 % |
| Notion reconnue (lexique / top-3 du classifieur) | 83 % / 62 % |
| Quasi-copies d'annales | 0 % |
| Python qui compile / SQL bien formé | 100 % / 100 % |
| Au-dessus de la plausibilité médiane des vraies questions | 31 % (référence : 50 %) |

Exemples :
- *recherche textuelle × « prédire le résultat d'un appel »* : « Donner la valeur renvoyée par cet appel. »
- *parcours d'arbre × « expliquer un fonctionnement »* : « Expliquer pourquoi le parcours infixe d'un ABR fournit ses valeurs dans l'ordre croissant. »
- *SoC, savoir jamais évalué* : « Quel élément d'un SoC permet à un smartphone de communiquer avec d'autres machines ? »

Limites :
- 9 des 25 manières de demander et 5 des 8 types de support sont jugés peu cohérents.
- La grammaire de plausibilité reste modeste (AUC 0,69).
- Une question inédite reste en moyenne un peu moins « typique » qu'une vraie question.

## Deuxième entraînement : plus de matière, auto-correction

Aucune variable n'a été ajoutée à la main. Le modèle a reçu plus de matière, et de nouveaux mécanismes lui permettent de se corriger seul.

**Nouvelle matière** (`scripts/fetch_sources.sh`, `examgen/ingest_extra.py`) :
- 96 sujets écrits officiels, dont ceux de [sujetdebac.fr](https://www.sujetdebac.fr) pour 2021–2026 ;
- [CodEx](https://codex.forge.apps.education.fr) : exercices avec étiquettes et difficulté ;
- une banque de QCM de Terminale ;
- 7 dépôts d'enseignants sur la Forge des communs numériques éducatifs.

Au total, environ 8 400 questions d'exposition.

**Mécanismes d'auto-correction** (`examgen/discovery.py`) :
- **Tri automatique.** Un classifieur sépare les vraies questions de la prose. Son seuil est choisi par F1 et il a écarté 1 303 unités.
- **Facettes stables.** Chaque groupe de k-means est rééchantillonné (Jaccard *clusterboot*). k est choisi par silhouette × stabilité, puis les groupes instables sont dissous en un seul tour. Les facettes sont apprises sur les sujets seulement, et les autres sources y sont projetées. Une première version avait fait s'effondrer les facettes (6 manières de demander) ; cette contrainte a corrigé le problème.
- **Réglages par validation croisée groupée.** La plausibilité et le classifieur de notions choisissent eux-mêmes leurs hyperparamètres.
- **Auto-apprentissage contrôlé.** Pseudo-étiquettes et auto-étiquetage du cours ne sont gardés que s'ils améliorent le score sur des sujets tenus à l'écart. Pour le cours, ce n'était pas le cas, et ils ont été refusés.
- **Validateur corrigé.** Il accepte les méthodes « à compléter » indentées et les lignes numérotées. Il ne vérifie plus le SQL cité dans une phrase.

| Mesure | Avant | Après |
|---|---|---|
| Sujets écrits / unités d'exposition | 83 / 3 102 | 96 / ≈ 8 400 |
| Manières de demander | 25 (silhouette 0,33) | 21 stables (0,37 ; stabilité 0,89) |
| Types de support | 8 | 16 stables (stabilité 0,89) |
| Notion top-3 (sujets tenus à l'écart) | 90,1 % | 95,6 % |
| Difficulté (R²) | 0,036 | 0,081 |
| Inédites : manière de demander respectée (top-3) | 71 % | 85 % |
| Inédites : notion reconnue (top-3) | 62 % | 74 % |
| Inédites : jugées plausibles | 31 % | 36 % |
| Inédites : combinaison jamais vue | 74 % | 77 % |
| Inédites : support respecté (top-3) | 81 % sur 8 types | 63 % sur 16 types |
| Python / SQL des corrigés | 100 % / 100 % | 98 % / 100 % |

La page `output/livrable.html` (construite par `python scripts/build_livrable.py`) regroupe les anciens sujets et les 368 questions générées, dont 163 inédites.

## Moteur générique : le « profil du professeur » (`examgen/prof`)

Il fonctionne pour n'importe quelle matière, à partir des anciens sujets (avec leurs corrigés si possible) et du cours. Rien n'est écrit à la main pour une matière donnée : le découpage repose uniquement sur la typographie (titres, numéros, « Annexe », barème). Tout le reste est appris :
- les parties pertinentes ;
- les manières de demander et leur ordre ;
- les formules rituelles ;
- les types d'annexes, recopiées ou inventées ;
- le niveau de détail par point ;
- les sections qui tombent ensemble ;
- la probabilité qu'une section tombe l'an prochain.

```
python -m examgen.prof profil --sujets DIR --cours DIR --out OUT   # profil appris
python -m examgen.prof plan   --sujets DIR --cours DIR --out OUT   # plans pour tout le cours
(agents rédacteurs : OUT/consignes_redacteur.md)
python -m examgen.prof check  --sujets DIR --cours DIR --out OUT   # validateur = récompense
python scripts/prof_revise.py prepare|keep_best|compare OUT        # boucle vérifier → réviser
```

**Pas besoin d'apprentissage par renforcement complet.** Le validateur appris joue le rôle de la récompense. Le rédacteur révise d'après ses retours, et une révision n'est gardée que si la note ne baisse pas (accepter/rejeter).

**Formules rituelles.** Le professeur repose les mêmes débuts de question d'un sujet à l'autre, comme « Développez l'argumentation juridique que… » (34 sujets). Ces tournures sont détectées automatiquement : un trigramme de début d'énoncé présent dans au moins 10 % des sujets. Les reprendre est admis. Recopier une ancienne situation, même avec d'autres noms, est refusé.

### Droit (bac STMG droit-économie)

Le corpus compte 38 sujets 2021–2026, 14 corrigés et le cours en 23 sections (programme Éduscol et articles des codes). Le moteur a gardé seul 43 parties juridiques et écarté 42 parties d'économie. Il a produit 49 documents (un cas et une série d'exercices par section, plus 3 sujets blancs), soit 196 questions et 124 annexes.

| Contrôle (196 questions) | 1re écriture | + formules rituelles | + révision |
|---|---|---|---|
| Manière de demander reconnue | 100 % | 100 % | 100 % |
| Section visée reconnue (top 3) | 87,8 % | 87,8 % | 93,4 % |
| Articles cités vérifiables | 100 % | 100 % | 100 % |
| Pas une copie | 77 % | 99,5 % | 100 % |
| Longueur du corrigé | 100 % | 100 % | 100 % |
| Annexes sources recopiées fidèlement | 100 % | 100 % | 100 % |
| Question qui passe tout | 69,4 % | 87,2 % | 93,4 % |

La colonne « 1re écriture » utilise l'ancien test de copie, qui confondait formules rituelles et copies ; la hausse de 77 % à 99,5 % vient de cette correction du contrôle, pas d'une réécriture. La révision a porté sur les 14 documents signalés : la section reconnue y passe de 57 % à 77 %, et les 14 révisions ont été gardées.

NSI : sur 45 questions révisées, 24 révisions ont été gardées et 21 rejetées. Le support reconnu sur l'ensemble des questions inédites passe de 63 % à 70 %.

Limites :
- la section n'est prédite qu'un peu mieux que par la popularité (AUC 0,635 contre 0,622) ;
- il n'y a que 14 corrigés ;
- les PDF scannés ne sont pas lus (pas d'OCR).

### Prévoir l'année suivante (`examgen/prof/forecast.py`)

Le but : écrire les questions les plus probables, dans la manière du professeur, avec ce qu'il exige sans le dire.

```
python -m examgen.prof.forecast droit                               # preuve + passages probables -> OUT/previsions.json
python -m examgen.prof probable --out OUT                           # plans des sujets probables -> OUT/plans_probables.json
python -m examgen.prof check --out OUT --plans plans_probables.json # contrôle de OUT/generated_probables/
```

- **Quel passage tombera.** Un modèle apprend sur les années passées quel passage du cours est interrogé. La preuve se fait « comme en vrai » : chaque année testée est prédite avec les seules années d'avant. On compte la part des vraies questions qui tombent dans les 10 % de passages retenus.
- **Comment il le demande.** Les manières de demander déjà employées sur ce passage ou ce chapitre.
- **L'intention cachée.** Les mots propres au chapitre que le professeur ne dit presque jamais dans ses énoncés (moins de 20 %) mais qu'il attend dans ses corrigés (au moins deux fois plus que dans l'ensemble des corrigés). Le contrôleur vérifie que le corrigé généré les exige et que l'énoncé ne les dit pas.

Droit, années testées 2024–2026 (27 passages retenus sur 274) :

| Méthode | Vraies questions couvertes | À un passage près |
|---|---|---|
| Hasard | 10 % | – |
| Popularité (ce qui tombe souvent) | 30 % | 41 % |
| Logistique, 12 variables (retenue pour 2027) | 46 % | 60 % |
| Méthode choisie seule chaque année | 30 % | 45 % |

Le score varie beaucoup selon l'année (95 % en 2024, 29 % en 2025, 15 % en 2026) : avec 6 années, une année surprise pèse lourd. Le chiffre prudent est celui de la méthode choisie seule. Les 3 sujets probables générés (12 questions, 8 annexes réelles ou inventées) passent tous les contrôles, et leurs corrigés couvrent toute l'intention cachée visée.

#### Programme d'entraînement sur tout le cours

Le but n'est pas de deviner juste à 100 %, mais que l'élève ait travaillé tout ce qui peut tomber. `forecast` classe donc **chaque chapitre** (clé `programme` de `previsions.json`) :

- **probabilité** : le modèle ci-dessus, qui tient compte de l'historique ;
- **potentiel** : un second modèle appris sans l'historique (place, centralité, insistance, références…). Il mesure le *genre* de passage que choisit le professeur, donc s'applique à un chapitre jamais tombé ;
- **niveau** : incontournable, probable, jamais ou peu tombé mais dans sa manière, à connaître ;
- pour chaque chapitre : ce qui est évalué sans être dit, ses consignes habituelles, les passages à maîtriser, les questions passées proches.

Preuve sur les nouveautés (questions portant sur un passage jamais interrogé avant, années 2024–2026) : la part qui tombe dans le quart des passages jugés « dans sa manière » est de 80 % en droit (23 questions) et 48 % en NSI (248 questions), contre 25 % au hasard.

`scripts/build_livrable.py` relie à chaque chapitre les exercices déjà rédigés (droit : cas et séries par section ; NSI : banques et inédits par notion), par similarité avec tout le texte du chapitre. Onglet « Programme d'entraînement » du livrable : droit 23 chapitres, NSI 41 chapitres et 474 questions.

## Une seule commande, n'importe quelle matière

```
python -m examgen.prof tout --nom eco --sujets data/sources/droit_stmg --cours data/eco/cours
```

Il suffit des anciens sujets (PDF) et du cours (Markdown, un titre `##` par partie). La commande enchaîne tout :
profil du professeur, plans, prévision de l'année suivante, rédaction, contrôle, livrable.
La matière est inscrite dans `data/domaines.json`, ses sorties vont dans `output/<nom>/`.

- **Tri automatique du cours** : si les sujets mêlent deux matières, un mélange gaussien (choisi par BIC)
  garde seulement les parties du cours fourni. Pour l'économie : 42 parties gardées, 43 de droit écartées.
- **Rédaction générique** (`examgen/prof/redige.py`) : les consignes du rédacteur sont tirées du profil appris
  (manières de demander, documents recopiés ou inventés, longueur des corrigés, intention cachée), sans règle
  propre à une matière. Chaque exercice passe au contrôle (`check.Checker`), et ce qu'il reproche est renvoyé
  au rédacteur, jusqu'à 2 fois. Avec `ANTHROPIC_API_KEY`, l'appel est direct. Sans clé, un prompt complet
  par plan est écrit dans `output/<nom>/prompts/`.

### 3e matière, jamais vue : économie STMG

Le cours est assemblé depuis les programmes Éduscol (`scripts/build_eco_cours.py`, 25 chapitres, 205 passages).
Le test se fait comme en vrai : chaque année 2024 à 2026 est prévue avec les années d'avant seulement.

| Mesure | Économie | Droit | NSI |
|---|---|---|---|
| AUC de la popularité | 0,73 | | |
| AUC du potentiel sur les passages jamais demandés | 0,69 | 0,84 | 0,62 |
| Nouveautés repérées dans le quart du haut (hasard : 25 %) | 41 % | 80 % | 48 % |

Avec un cours trop maigre (58 passages), ce taux tombait à 0 % : la qualité du cours compte autant que les sujets.
Le sujet le plus probable (SP-1, commerce mondial et IDE) a passé tous les contrôles au premier jet.

## Méta-apprentissage (`examgen/meta`)

### Auto-progression de la prévision (`examgen/meta/autoprog.py`)

Le moteur fabrique ses propres variables et choisit lui-même lesquelles garder :

- **familles générées** : mémoire pondérée (demi-vies 1 et 3 ans), voisinage dans le cours,
  proximité avec ce qui a déjà été demandé, lexique du professeur (ses énoncés et corrigés),
  rotation des chapitres, thèmes du cours, récence ;
- **générations** : on part des 12 variables de base et on ajoute, une par une, la famille (et le
  modèle : logistique, arbres ou mélange) qui améliore la validation « année exclue » sur les
  années passées ;
- **a priori entre matières** : ce que les autres matières ont adopté donne un petit bonus ;
- **prudence** : le choix est fait sur peu d'années, donc la prédiction finale moyenne ses rangs
  avec l'ancienne méthode.

Preuve honnête (chaque année 2024–2026 prédite avec les seules années d'avant, a priori appris
sans la matière testée) :

| Matière | Questions de l'année couvertes (10 % des passages) | AUC | Questions jamais posées couvertes (quart retenu) | AUC |
|---|---|---|---|---|
| Droit | 30 % → **45 %** | 0,76 → 0,81 | 80 % → 80 % | 0,84 → 0,85 |
| NSI | 72 % → **74 %** | 0,80 → 0,83 | 48 % → **64 %** | 0,62 → 0,73 |
| Économie | 25 % → 22 % | 0,73 → 0,74 | 41 % → **52 %** | 0,69 → 0,73 |

L'AUC monte partout ; la couverture monte ou reste égale 5 fois sur 6. En économie (peu de
questions par an), la prévision reste fragile. La règle « mêler à l'ancienne méthode » a été
retenue après comparaison sur ces trois matières : c'est un léger biais de sélection.

```bash
python -m examgen.meta.autoprog own droit nsi eco      # ce que chaque matière retient seule
python -m examgen.meta.autoprog honest droit droit nsi eco  # preuve (une matière par appel)
python -m examgen.meta.autoprog combine droit nsi eco  # règle -> data/model/autoprog.json
```

### Règle universelle pour les domaines inconnus (`examgen/meta/transfer.py`)

En production, le moteur ne sera pas entraîné pour chaque matière : il reçoit le cours et les
anciens sujets, et doit répondre. Le méta-entraînement vise donc les matières **jamais vues**.

- **Tâches** : chaque (matière, année) et 5 « pseudo-domaines » par matière (la moitié des
  chapitres tirée au hasard), soit 106 tâches ; 61 candidats (familles × modèles, purs ou mêlés).
- **Ce qui n'a pas marché** : un juge appris (ExtraTrees sur les traits du domaine) qui choisit
  le candidat par matière. Testé sur une matière exclue, il fait moins bien qu'une règle fixe :
  avec deux matières d'entraînement, il apprend leurs particularités, pas une loi générale.
  Le choix glouton par matière (`autoprog`) sur-apprend aussi quand il y a peu de données.
- **Ce qui est retenu** : une seule règle, la même partout, choisie pour marcher en moyenne
  **et** dans le pire domaine. Prévision : lexique du professeur + arbres. Nouveautés : lexique
  du professeur + mélange, mêlé à l'ancienne méthode.

Preuve « matière inconnue » : la règle est choisie sans la matière testée, puis appliquée à elle
(chaque année 2024–2026 prédite avec les seules années d'avant).

| Matière | Questions de l'année (10 %) | AUC | Questions jamais posées (quart) | AUC |
|---|---|---|---|---|
| Droit | 30 % → **43 %** | 0,76 → 0,81 | 80 % → 80 % | 0,84 → 0,84 |
| NSI | 72 % → **75 %** | 0,80 → 0,82 | 48 % → **64 %** | 0,62 → 0,73 |
| Économie | 25 % → 19 % | 0,73 → 0,76 | 41 % → **67 %** | 0,69 → 0,78 |

L'AUC monte dans les 6 cas. La couverture monte ou reste égale 5 fois sur 6 ; la prévision en
économie (peu de questions par an) reste le point faible. Sur les pseudo-domaines, la règle finale
gagne 5 fois sur 6 (NSI prévision : 68 % → 67 %).

**Auto-jugement** : avant de répondre, le moteur rejoue la règle sur ses propres années et
annonce une fourchette de couverture. Mesuré sur les 106 tâches, la fourchette contient le vrai
résultat 86 % du temps (largeur moyenne 0,65 : peu d'années donnent une estimation large, et le
moteur le dit au lieu d'annoncer un chiffre trop précis).

Avec seulement 3 matières, cette règle n'était pas prouvée universelle : voir ci-dessous, le méta-entraînement sur 14 matières.

```bash
python -m examgen.meta.transfer tasks droit        # (une matière par processus)
python -m examgen.meta.transfer judge droit nsi eco  # juge appris (pour comparaison)
python -m examgen.meta.transfer rule droit nsi eco   # règle retenue -> output/meta/regle.json
```

### Méta-entraînement sur 14 matières : apprendre à se régler

Pour ne pas se spécialiser, le moteur a été méta-entraîné sur 14 matières de bac aux formats très
différents : droit, économie, NSI, SES, SVT, physique-chimie, maths, HGGSP, HLP, SI, management,
ST2S (SSS), STL (CBPH) et STI2D (I2D). Cela représente 445 tâches (années et pseudo-domaines).
Cours : programmes officiels publiés sur eduscol. Annales : sujets de bac 2021–2026.

Ce qu'il a fallu rendre générique, sans aucune règle propre à une matière :
- `prof/pdfcours.py` : lit un cours PDF quelconque d'après sa typographie (taille, gras, couleur
  des titres, tableaux). Le niveau de titre qui sert de « section » est choisi sur le document
  lui-même. Sert aussi en production, quand un élève envoie son cours en PDF.
- `prof/docs.py` : sujets en « QUESTION n : » et sujets à consigne unique (dissertation,
  commentaire), en plus des questions numérotées.
- `prof/profile.py` : le filtre des parties « hors cours » ne peut plus écarter presque tout un
  sujet. S'il garde moins de 20 % des parties, il n'a pas trouvé d'intrus et garde tout.

Stade `learn` : chaque matière est traitée comme inconnue. Tout ce qui est appris (règle, juge,
liste de réglages, seuil, prudence) l'est sur les 19 autres. Méta-entraînement sur **20 matières**
(643 tâches) : les 14 précédentes plus philosophie, français, LLCER anglais, espagnol, allemand,
physique-chimie-maths STI2D. L'italien est écarté : 12 questions sur 4 années.

| Nouveautés (passages jamais tombés), matière exclue | Couverture | AUC | Gagnées / perdues | Pire matière |
|---|---|---|---|---|
| Ancienne méthode | 41 % | 0,63 | — | — |
| Juge appris | 51 % | 0,66 | 14 / 5 | −0,255 |
| Se régler soi-même | 42 % | 0,64 | 4 / 3 | −0,100 |
| **Règle unique, prudence apprise (retenue)** | **53 %** | **0,71** | **16 / 4** | −0,184 |

- **Prudence apprise.** L'ancien critère « moyenne + pire domaine » se durcit à chaque domaine
  ajouté : le pire de 120 domaines est presque toujours mauvais. À 20 matières, il ne retenait plus
  aucune règle (couverture retombée à 41 %). Le degré de prudence (pire, quantile 10 %, quantile
  25 %, moyenne) est désormais choisi par validation emboîtée : pour chaque matière testée, il est
  choisi sur les autres seulement. Il retient « moyenne » pour les nouveautés et garde le plus
  prudent pour la prévision.
- La règle retenue n'est plus « voisinage + mélange » (14 matières) mais « lexique du professeur
  + arbres ». Avec plus de matières, la règle change : c'est le but du méta-entraînement.
- **Prévision** : sur 20 matières, aucun réglage ne bat l'ancienne méthode (couverture 50 %,
  AUC 0,78). Le moteur garde l'ancienne méthode.
- **Auto-jugement** : la fourchette annoncée contient le vrai résultat dans 85 % des 643 tâches,
  mais elle est large (0,79 en moyenne) : elle informe peu.
- **Contrôle** : les caches ont été effacés et tout a été recalculé à froid. Sur les 14 anciennes
  matières, on retrouve exactement l'ancien résultat (40 % → 47 %). L'écart vient donc des
  nouvelles matières, pas des caches.

`apply()` relit `output/meta/apprendre.json` (stratégie adoptée par objectif) et peut choisir
seul dans une liste si un futur méta-entraînement la retient.

```bash
scripts/fetch_matieres.sh && scripts/fetch_programmes.sh   # annales + programmes -> data/
python -m examgen.meta.transfer tasks ses                  # une matière par processus
python -m examgen.meta.transfer learn sss management cbph i2d hggsp hlp ses droit eco svt si nsi physique maths philo francais anglais espagnol allemand pcm
python -m examgen.meta.transfer rule  sss management cbph i2d hggsp hlp ses droit eco svt si nsi physique maths philo francais anglais espagnol allemand pcm
```

`forecast.run` applique cette règle à la vraie prévision de l'année suivante, sans réglage par matière.
Le moteur limite OpenMP à un thread (`examgen/__init__.py`) : sur ces petits jeux, plusieurs
threads rendaient le modèle par arbres 300 fois plus lent.

**Vitesse, à résultats identiques** (`examgen/fast.py`). Chaque accélération a été vérifiée en
comparant les sorties à celles de l'ancien code, nombre par nombre (écart maximal 2e-16).

| Étape (SI) | Avant | Après |
|---|---|---|
| Tâches de méta-entraînement | 134 s | 39 s |
| Prévision à froid | 75 s | 19 s |
| Prévision avec cache | 9 s | 5 s |

- AUC calculée par les rangs : même formule que scikit-learn, sans ses vérifications (15× plus rapide).
- Les calculs indépendants (pseudo-domaines, années de validation) sont répartis sur tous les
  cœurs, sans changer leur ordre. `EXAMGEN_JOBS=1` revient au calcul sur un seul cœur.
- Le texte des PDF est mis en cache (clé : empreinte du fichier) et lu en parallèle.
- Correctif trouvé au passage : le cache de lecture oubliait le réglage choisi par le moteur. Un
  second passage donnait donc une autre prévision que le premier. Les deux sont maintenant identiques.

### Autocritique : le moteur cherche seul pourquoi il rate (`examgen/meta/critique.py`)

Après le méta-entraînement, environ la moitié des questions restaient ratées, la fourchette annoncée
était trop large et rien ne vérifiait les seuils du correcteur. Plutôt que de corriger à la main, le
moteur se critique. Chaque réglage est écrit comme un mélange de rangs de 21 réglages de base. À chaque tour :

1. **Critique.** Parmi ses questions ratées, quelle part chaque autre réglage aurait trouvée
   (« rattrapeurs ») ? Les ratés tombent-ils dans des chapitres dont il n'a retenu aucun passage ?
2. **Propositions.** Mêler un rattrapeur (part 0,25 / 0,5 / 1), ou étaler sa sélection sur plus de
   chapitres (diversification).
3. **Décision.** Une proposition n'est gardée que si elle gagne selon le critère de prudence appris.
   Sinon il s'arrête (6 tours au plus).

Tout est validé matière exclue : la recherche est refaite sans la matière testée. Sur 20 matières (643 tâches) :

| Nouveautés, matière exclue | Couverture | Pire matière | Gagnées / perdues |
|---|---|---|---|
| Ancienne méthode | 41 % | — | — |
| Règle apprise (avant) | 53 % | −18,4 pts | 16 / 4 |
| **Après autocritique (retenue)** | **57 %** | **−12,5 pts** | **16 / 3** |

- Ce qu'il s'est dit : « 53 % de mes ratés tombent dans des chapitres que je n'ai pas retenus ».
  Il a essayé plusieurs rattrapeurs. Il a gardé « lexique du professeur, modèle logistique » mêlé à
  son réglage par arbres (1/3 – 2/3) et refusé le reste (pas de gain prouvé). La diversification
  par chapitre n'a jamais été retenue.
- **Prévision** : rien ne bat l'ancienne méthode (49 %, AUC 0,78). Elle est gardée.
- **Fourchette** : une fourchette apprise (centre et erreur typique par arbres, facteur calibré
  hors matière) est juste aussi souvent (86 %) mais **plus large** (0,84 contre 0,78). Le moteur
  garde la marge fixe : sa fourchette reste peu informative.
- `transfer.apply()` utilise le mélange retenu s'il existe (`output/meta/critique.json`), sinon la
  règle d'avant.

**Le correcteur se critique aussi** (`examgen/meta/controle.py`). Il juge un exercice « trop proche
d'un ancien sujet » au-delà d'un cosinus de 0,85, fixé à la main. Il passe donc au contrôle les vraies
questions du professeur, chaque année face aux années d'avant seulement. Il essaie deux seuils
appris matière exclue : un seuil commun, et un seuil propre à chaque professeur (quantile de ce qu'il
s'est permis avant). Résultat : aucun ne fait mieux que 0,85 sans faire échouer une matière, il est
gardé. 0,85 laisse passer 99,5 % des vrais énoncés et 88 % des vraies situations. Défaut repéré :
en français et en espagnol, le professeur réutilise les mêmes mises en situation, et le correcteur
les refuse presque toutes. `prof/check.py` lit désormais ses seuils dans `output/meta/controle.json`.

```bash
python -m examgen.meta.transfer tasks <matière>     # garde aussi les prédictions de base
python -m examgen.meta.critique droit nsi eco ...   # autocritique -> output/meta/critique.json
python -m examgen.meta.controle droit nsi eco ...   # seuils du correcteur -> output/meta/controle.json
```

`python -m examgen.meta.learn` → `output/meta/rapport.json` et `data/model/meta.json`.

- `align.py` : le moteur choisit seul sa façon de lire (règle apprise sur une matière, testée sur l'autre).
- `selftrain.py` : auto-entraînement par générations (v0 → v1 → …). Cohérence de partie, puis un élève entraîné sur le cours corrige son maître. Un garde-fou sans étiquette refuse les reculs. Droit 78 % → 87 %, NSI 77 % → 82 % (top 3, matière exclue). Appelé par `Teacher.align` quand les corrigés ne citent pas le cours.
- `intent.py` : environ 30 variables d'intention cours ↔ question, retenues par tâches auto-supervisées.
- `deep.py` : 312 variables générées, sélection par stabilité, transfert à froid entre matières.
- `loop.py` : matière inconnue, sans entraînement préalable. À partir des seuls anciens sujets et du cours, le moteur découvre des variables propres à la matière : thèmes et formes (NMF sur le cours), nommés par leurs mots. Il choisit sa famille de modèles par validation emboîtée sur ses années, puis réinjecte ce qu'il a compris des intentions dans l'alignement, sur plusieurs générations. Aucune règle n'est transportée d'une matière à l'autre ; seule la procédure est commune.
